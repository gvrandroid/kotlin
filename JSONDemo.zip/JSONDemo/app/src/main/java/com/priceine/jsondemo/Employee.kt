package com.priceine.jsondemo

data class Employee( val empName:String, val empPhone:String, val empDesignation: String){}
