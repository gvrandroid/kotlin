package com.priceine.jsondemo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class EmployeeAdapter(val empList: ArrayList<Employee>) : RecyclerView.Adapter<EmployeeAdapter.MyViewHolder>() {
    class MyViewHolder(listItem: View): RecyclerView.ViewHolder(listItem){
        val empName: TextView = listItem.findViewById(R.id.emp_name)
        val empPhone: TextView = listItem.findViewById(R.id.emp_phone)
        val empDesg: TextView = listItem.findViewById(R.id.emp_desg)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val empItem = LayoutInflater.from(parent.context).inflate(R.layout.list_item,parent,false)
        return MyViewHolder(empItem)

    }



    override fun getItemCount(): Int {
        return empList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val emp = empList[position]
        holder.empName.text = emp.empName
        holder.empPhone.text = emp.empPhone
        holder.empDesg.text = emp.empDesignation
    }

}
