package com.priceine.jsondemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    lateinit var recyclerView: RecyclerView
    lateinit var empList: ArrayList<Employee>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        recyclerView = findViewById(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)
        empList = ArrayList()

        val fileObject = JSONObject(loadJsonFromAssets())
        val employees =  fileObject.getJSONArray("employees")
        for (item in 0 until  employees.length()){
        val employeeDetails = employees.getJSONObject(item)
            val name = employeeDetails.getString("Name")
            val qual = employeeDetails.getString("Qualification")
            val phone = employeeDetails.getJSONObject("phone")
            val mobileNumber = phone.getString("mobile")
            val officeNumber = phone.getString("office")
            val designation = employeeDetails.getString("designation")
            empList.add(Employee(name,mobileNumber,designation))
        }


        recyclerView.adapter =EmployeeAdapter(empList)

    }

    private fun loadJsonFromAssets(): String {
        val json:String?
    val inputStream = assets.open("priceline.json")
        val size = inputStream.available()
        val buffer = ByteArray(size)
        inputStream.read(buffer)
        inputStream.close()
        json = String(buffer)

        return json
    }
}