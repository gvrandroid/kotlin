package com.priceine.loginvaidation

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var emailEt:EditText
    private lateinit var passwordEt:EditText
    private lateinit var signInBtn:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //loading Views
        emailEt = findViewById(R.id.email_et)
        passwordEt = findViewById(R.id.pwd_et)
        signInBtn = findViewById(R.id.sign_in_btn)

        //setting Listeners
        signInBtn.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        val email = emailEt.text.toString()
        val password = passwordEt.text.toString()
        val builder = AlertDialog.Builder(this)
        builder.setTitle("PriceLine Alert")

        if (emailEt.text.isNotEmpty() && passwordEt.text.isNotEmpty()){
            if (email == "priceline" && password == "Price@1234")
            {
                val intent = Intent(this,WelcomeUser::class.java)
                startActivity(intent)
            }
            else{
                builder.setMessage("Invalid User!")
                Toast.makeText(this,"Invalid User!",Toast.LENGTH_LONG).show()
            }
        }
        else{
            builder.setMessage("Please Enter Login Details..!")
            Toast.makeText(this,"Please Enter Login Details..!",Toast.LENGTH_LONG).show()
        }
        builder.setPositiveButton("Login",DialogInterface.OnClickListener { dialog, which ->
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        })
        builder.setNegativeButton("cancel",DialogInterface.OnClickListener { dialog, which ->
            dialog.dismiss()
        })
        val alertDialog = builder.create()
        alertDialog.show()
    }
}


